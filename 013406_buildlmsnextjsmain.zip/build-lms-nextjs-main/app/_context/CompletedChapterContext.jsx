import { createContext } from "react";

export const CompletedChapterContext=createContext(null);