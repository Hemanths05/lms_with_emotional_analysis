import React from 'react'

function WatchCourseLayout({children}) {
  return (
    <div>
        {children}
    </div>
  )
}

export default WatchCourseLayout